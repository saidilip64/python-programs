number = input("Enter a number ")
x = int(number)%2
if x == 0:
    print(" The number is Even ")
else:
    print(" The number is odd ")
