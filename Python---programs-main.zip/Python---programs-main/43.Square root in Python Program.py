def sqrt(n):

    x=n**0.5

    print(x)

n=int(input("Enter the number whose square root you need to find: "))

sqrt(n)
