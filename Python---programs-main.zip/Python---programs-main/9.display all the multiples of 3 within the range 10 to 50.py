for i in range(10,50):
    if (i%3==0):
        print(i)
