a = 3
square = a * a
print(square)
