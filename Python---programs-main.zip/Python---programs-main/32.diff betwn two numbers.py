# Python program to find difference between two numbers

# first number
num1 = 25
# second number
num2 = 13

# num1 is greater than num2
if num1 > num2:
    diff = num1 - num2
# num1 is less than num2
else:
    diff = num2 - num1

# print difference value
print('The difference between numbers =', diff)
