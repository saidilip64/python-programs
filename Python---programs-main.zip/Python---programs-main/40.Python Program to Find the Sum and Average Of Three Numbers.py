num1 = int(input("Please Enter the First Number  = "))
num2 = int(input("Please Enter the Second number = "))
num3 = int(input("Please Enter the Third number  = "))


sumOfThree = num1 + num2 + num3

avgOfThree = sumOfThree / 3

print('The sum of {0}, {1} and {2} = {3}'.format(num1,num2, num3, sumOfThree))
print('The Average of {0}, {1} and {2} = {3}'.format(num1,num2, num3, avgOfThree))
