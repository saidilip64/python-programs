# Initializing a dictionary with some elements   
Dictionary = {1: 'Javatpoint', 2: 'Python', 3: 'Dictionary'}  
print("\nDictionary created using curly braces: ")  
print(Dictionary)  
# Creating a Dictionary with keys of different data types  
Dictionary = {'Website': 'Javatpoint', 3: [2, 3, 5, 'Dictionary']}  
print("\nDictionary with keys of multiple data type: ")  
print(Dictionary)  
