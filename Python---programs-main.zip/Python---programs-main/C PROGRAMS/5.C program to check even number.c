#include <stdio.h>
main() 
{
  int a;
  printf("Enter the value of a: ");
  scanf("%d",&a);
  if (a%2 == 0) 
  {
    printf("%d is even number.", a);
  }
} 
