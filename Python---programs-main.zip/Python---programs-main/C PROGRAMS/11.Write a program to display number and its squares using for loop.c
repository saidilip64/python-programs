#include <stdio.h>
main() 
{
  int i;
  printf("Number\tSquare");
  for(i = 1; i <= 10; i++);
  {
    printf("\n%d\t%d",i, i*i);
  }
}
