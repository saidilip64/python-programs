student_marks = [56, 78, 96, 37, 85]  
student_dict = {'Abhinay': 56, 'Sharma': 78, 'Himanshu': 96, 'Peter': 37}  
Input : ['Name', 'Abhinay', 'age', 25, 'Marks', 90]  
Output : {'Name', 'Abhinay', 'age', 25, 'Marks', 90}  
  
Input : ['a', 10, 'b', 42, 'c', 86]  
Output : {'a', 10, 'b', 42, 'c', 86}  
