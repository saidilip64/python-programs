import numpy

x=numpy.array([[1,2], [3,4]])

y=numpy.linalg.inv(x)

print(x)

print (y)
