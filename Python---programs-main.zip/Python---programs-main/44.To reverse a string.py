string=input("Enter a string:")

revstring=string[::-1]  //performs the reverse of the string

print(revstring)    // print the reversed string
