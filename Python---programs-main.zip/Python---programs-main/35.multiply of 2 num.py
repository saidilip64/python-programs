num1 = float(input("Please Enter the First  = "))
num2 = float(input("Please Enter the second = "))

mul = num1 * num2
print('The Result of Multipling {0} and {1} = {2}'.format(num1, num2, mul))
